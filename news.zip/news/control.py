import re
import os

def che():
    files = os.listdir()
    return files

def get_data(file_name):
    with open(file_name) as f:
        raw_text = f.read()
    return raw_text

def freqe(text):
    pos = re.findall("([А-Я-]+)\W", text)
    pos_freq_d = {p: pos.count(p) for p in pos}
    return pos_freq_d

def meta(text):
    pos = re.findall('content=".+" name="tagging"', text)
    pos_freq_d = {p: pos for p in pos}
    with open('freq.csv', 'a') as f:
        for p in 
        f.write("")
        
def tex():
    with open('freq.txt', 'w') as f:
        f.write('аббревиатура'+'\t'+'количество вхождений'+'\n')
        
def dict_to_tex(freq_dict):
    with open('freq.txt', 'a') as f:
        for p in freq_dict:
            f.write(p + '\t' + str(freq_dict[p]) + '\n')
    print('Done.')

if __name__ == '__main__':
    tex()
    files = che()
    for file in files:
        raw = get_data(file)
        freq = freqe(raw)
        dict_to_tex(freq)
 

