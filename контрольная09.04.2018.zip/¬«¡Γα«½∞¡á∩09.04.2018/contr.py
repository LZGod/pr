import re
import collections
def file(a):
    with open(a, encoding="utf-8") as f:
        text = f.readlines()
        for line in text:
            if "</teiHeader>" in line:
                i = text.index(line)
        s = str(i)
#        for line in text:
#            if "<w lemma=" in line:               
    with open("otw.txt", "w", encoding="utf-8") as t:
        t.write(s)
def main():
    file("11.xml")

if __name__ == '__main__':
    main()  
