import os
start = 'bbc'
fnames = os.listdir(start)
for name in fnames:
    path_to_file = os.path.join(start, name)
    if os.path.isfile(path_to_file):
        print(name + " is a file")
    elif os.path.isdir(path_to_file):
        print(name + " is a folder")

