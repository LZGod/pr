import os
start = 'bbc'
fnames = os.listdir(start)
ftypes = {}
for name in fnames:
    if '.' not in name:
        new = os.path.join(start, name)
        print(new)
        inner_files = os.listdir(new)
        print(len(inner_files))
