import os
start = 'bbc'
path_to_readme = os.path.join(start, 'README.TXT')
fnames = os.listdir(start)
if os.path.exists(path_to_readme):
    print("yes")
    with open(path_to_readme) as f:
        txt = f.read()
        print(txt)
else:
    print("no")
