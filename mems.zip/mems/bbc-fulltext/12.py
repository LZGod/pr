import os
fnames = os.listdir('bbc/business')
ftypes = {}
for name in fnames:
    print(name)
    ext = name.split('.')[-1]
    if ext in ftypes:
        ftypes[ext] += 1
    else:
        ftypes[ext] = 1
print(ftypes)
