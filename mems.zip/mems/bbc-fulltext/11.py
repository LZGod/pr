import os
i = 0
t = 0
fnames = os.listdir('bbc/business')
for name in fnames:
    if '.txt' in name.lower():
        t +=1
    i = i+1
print(fnames)
print(i, t)
