import os
start = 'bbc'
fnames = os.listdir(start)
ftypes = {}
for name in fnames:
    if '.' not in name:
        inner_files = os.listdir(start + '/' + name)
        print(inner_files)
